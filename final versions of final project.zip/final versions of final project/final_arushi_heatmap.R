#load data for heat map and store it in a variable
data <- read.table("GSE113857_TPM_matrix.txt",head=T,row.names=1,sep="\t",stringsAsFactors=F)
#selected the specific genes given in the paper
genes<- c("DCN","IBSP","EDNRB","GLUL","IER3","AXL","NT5E","RBM24","CRIM1","UGCG","HSPG2","MN1",
          "MAP2K3","IL6","CCL2","CXCL12","IGF2","DLK1","ATF3","PDGFB","PDGFRB","PDGFA","FZD7")
#match the desired genes into the TPM matrix and create the dataframe for all those selected genes [a].
a <- data[genes,]
# imported library uses to make heat map
library(pheatmap)
library(grid)
#method used for distance
#distance<- as.dist(1-cor(t(a), method = 'spearman'))
#distance<- as.dist(1-cor(t(a), method = 'kendall'))
distance<- as.dist(1-cor(t(a),method = 'pearson')) 
#method used for cluster
#cluster<- hclust(distance, method = 'ward.D')
#cluster<- hclust(distance, method = 'single')
cluster<- hclust(distance, method = 'ward.D2') 
#color used as gradient
p <- colorRampPalette(colors = c('blue','white','red'))
#save as pdf
pdf(paste0('shrivastava_heatmap.pdf'))  
#Decorating the heatmap as per given in the paper
pheatmap(a,p(50),scale='row',cluster_rows = cluster,cluster_cols = F,legend = T,show_rownames = T,show_colnames = T)
dev.off() #close
