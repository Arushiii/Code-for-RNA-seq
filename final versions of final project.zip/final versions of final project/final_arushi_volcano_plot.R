#importing the library
library('ggplot2') 
#storing the data in variable (d)
d= read.table(file= 'DEGs_tablefinalone.txt',head=T,row.names = 1,stringsAsFactors = F)
#try to create one more column with condition that depict the Upregulation and Downregulation using FDR AND LOG2FOLDCHANGE
d$u_d <- 'N'
#condition for upregulated and downregulated according to the paper
d$u_d[d$FDR <=0.05 & d$log2.FC. >= 1] <- 'upregulated'
d$u_d[d$FDR <=0.05 & d$log2.FC. <= -1] <- 'downregulated'
d$u_d <- factor(d$u_d,levels = c('downregulated','N','upregulated'),order = T)
table(d$u_d) # thus gives downregulated= 350 , upregulated= 250
#saving my plot as .pdf format
pdf(paste0("shrivastava_volcano_plot.pdf"))
#assigning the axis to be considered for the plot i.e. x and y axis
ggplot(data=d, aes(x=log2.FC., y=-log10(FDR), colour=u_d, fill=u_d)) +
  #setting the colour acc. to paper
  scale_color_manual(values=c("green", "black","red"))+
  #now scatter plot
  geom_point(alpha=1,size=1) +
  #setting lines on both axis
  geom_vline(xintercept=c(-1,1),lty=4,col="black",lwd=0.5)+
  geom_hline(yintercept = -log10(0.05), color="black", linetype='dashed') +
  #now setting up the axis x and y
  ylim(0,50) + xlim(-5,5) +
  #now labeling them
  labs(x="log2(Fold Change)",y="-log10 (FDR)",title="Volcano Plot")
#close
dev.off()